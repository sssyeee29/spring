/*package org.sample.service;

import java.util.List;

import org.sample.domain.Criterial;
import org.sample.domain.ReplyPageDTO;
import org.sample.domain.ReplyVO;

public interface ReplyService {

	public int register(ReplyVO vo);
	
	public ReplyVO get(Long rno);
	
	public int modify(ReplyVO vo);
	
	public int remove(Long rno);
	
	public List<ReplyVO> getList(Criterial cri, Long bno);

	public ReplyPageDTO getListPage(Criterial cri, Long bno);
}*/
